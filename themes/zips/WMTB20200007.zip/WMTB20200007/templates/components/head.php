<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() ?>/assets/css/style.css">
<link rel="stylesheet" href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() ?>/assets/css/solve.css">
